// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"

#include <vector>
#include <memory>
#include <cassert>
#include <stdexcept>

// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    void SetUp() override
    {
        // initialize random seed
        srand(static_cast<unsigned int>(time(nullptr)));
    }

    void TearDown() override {}
};

// test fixture that owns a shared collection for each test
class CollectionTest : public ::testing::Test
{
protected:
    // smart pointer to the test collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        // new empty collection before each test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        // clear contents and release storage
        collection->clear();
        collection.reset(nullptr);
    }

    // add random values [0, 99] to collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
        {
            collection->push_back(rand() % 100);
        }
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// ASSERT_*: aborts current test on failure (preconditions, critical assumptions).
// EXPECT_*: reports failure but continues running the rest of the test body.

// Test that a collection smart pointer is valid when created
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0u);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
 //TEST_F(CollectionTest, AlwaysFail)
 //{
 //    FAIL();
 //}

 // Verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0u);

    add_entries(1);

    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 1u);
}

// Verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    ASSERT_TRUE(collection->empty());
    add_entries(5);
    EXPECT_EQ(collection->size(), 5u);
}

// Verify max_size is >= size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsAlwaysAtLeastSize)
{
    // 0 entries
    EXPECT_GE(collection->max_size(), collection->size());

    // 1 entry
    add_entries(1);
    EXPECT_GE(collection->max_size(), collection->size());

    // 5 entries total
    add_entries(4);
    EXPECT_GE(collection->max_size(), collection->size());

    // 10 entries total
    add_entries(5);
    EXPECT_GE(collection->max_size(), collection->size());
}

// Verify capacity is >= size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsAlwaysAtLeastSize)
{
    // 0 entries
    EXPECT_GE(collection->capacity(), collection->size());

    // 1 entry
    add_entries(1);
    EXPECT_GE(collection->capacity(), collection->size());

    // 5 entries total
    add_entries(4);
    EXPECT_GE(collection->capacity(), collection->size());

    // 10 entries total
    add_entries(5);
    EXPECT_GE(collection->capacity(), collection->size());
}

// Verify resizing increases the collection size
TEST_F(CollectionTest, ResizeCanIncreaseSize)
{
    add_entries(3);
    ASSERT_EQ(collection->size(), 3u);

    collection->resize(8);
    EXPECT_EQ(collection->size(), 8u);
}

// Verify resizing decreases the collection size
TEST_F(CollectionTest, ResizeCanDecreaseSize)
{
    add_entries(10);
    ASSERT_EQ(collection->size(), 10u);

    collection->resize(4);
    EXPECT_EQ(collection->size(), 4u);
}

// Verify resizing down to zero clears the collection
TEST_F(CollectionTest, ResizeToZeroClearsCollection)
{
    add_entries(5);
    ASSERT_FALSE(collection->empty());

    collection->resize(0);
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0u);
}

// Verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    add_entries(7);
    ASSERT_FALSE(collection->empty());

    collection->clear();
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0u);
}

// Verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseRangeErasesCollection)
{
    add_entries(6);
    ASSERT_EQ(collection->size(), 6u);

    collection->erase(collection->begin(), collection->end());
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0u);
}

// Verify reserve increases capacity but not size
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    size_t initialSize = collection->size();
    size_t initialCapacity = collection->capacity();

    collection->reserve(initialCapacity + 10);

    EXPECT_EQ(collection->size(), initialSize);
    EXPECT_GE(collection->capacity(), initialCapacity + 10);
}

// Negative test: at() throws std::out_of_range for invalid index
TEST_F(CollectionTest, AtThrowsOutOfRangeOnInvalidIndex)
{
    add_entries(3);
    ASSERT_EQ(collection->size(), 3u);

    EXPECT_THROW(collection->at(3), std::out_of_range);
    EXPECT_THROW(collection->at(100), std::out_of_range);
}

// Custom positive test: values added are retrievable in order
TEST_F(CollectionTest, ValuesAreStoredInInsertionOrder)
{
    collection->push_back(10);
    collection->push_back(20);
    collection->push_back(30);

    ASSERT_EQ(collection->size(), 3u);
    EXPECT_EQ(collection->at(0), 10);
    EXPECT_EQ(collection->at(1), 20);
    EXPECT_EQ(collection->at(2), 30);
}

// Custom negative test: front() on empty vector is undefined � avoid by checking
// Here we verify our precondition check, not front() itself
TEST_F(CollectionTest, FrontIsNotCalledOnEmptyCollection)
{
    // precondition should fail if collection is empty
    EXPECT_TRUE(collection->empty());

    // guard condition: we would assert or throw in real code instead of calling front()
    // In this test, we simply confirm the guard and do NOT call front() when empty.
    if (!collection->empty())
    {
        // This block should not run in this test
        FAIL() << "front() should not be used on an empty collection";
    }
}