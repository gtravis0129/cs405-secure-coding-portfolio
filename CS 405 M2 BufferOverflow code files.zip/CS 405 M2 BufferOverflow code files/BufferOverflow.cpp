// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // account_number must stay here, directly before the input buffer
    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    std::cout << "Enter a value (max 19 characters): ";

    // use std::string to safely capture any length of input
    std::string temp;
    std::cin >> temp;

    if (temp.size() >= sizeof(user_input))
    {
        // too much data for the fixed buffer (remember space for '\0')
        std::cout << "Warning: you entered too many characters. "
            "Input will be truncated to fit the buffer."
            << std::endl;

        // copy only the first 19 characters and add a null terminator
        std::size_t maxChars = sizeof(user_input) - 1;
        temp.copy(user_input, maxChars);
        user_input[maxChars] = '\0';
    }
    else
    {
        // fits safely in user_input (including null terminator)
        temp.copy(user_input, temp.size());
        user_input[temp.size()] = '\0';
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}
