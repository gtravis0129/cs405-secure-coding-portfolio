// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept>
#include <string>

// Custom application-level exception
class CustomApplicationException : public std::exception
{
public:
    explicit CustomApplicationException(const std::string& message)
        : msg_(message)
    {
    }

    const char* what() const noexcept override
    {
        return msg_.c_str();
    }

private:
    std::string msg_;
};

bool do_even_more_custom_application_logic()
{
    // Simulate a failure in deeper application logic
    throw std::runtime_error("do_even_more_custom_application_logic failed unexpectedly.");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex)
    {
        std::cout << "[Error] std::exception in do_custom_application_logic: "
            << ex.what() << std::endl;
    }

    // Signal a higher-level application error
    throw CustomApplicationException(
        "Custom application logic encountered a critical error.");

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    if (den == 0.0f)
    {
        // Guard against invalid input
        throw std::invalid_argument("divide: denominator must not be zero.");
    }

    return num / den;
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0.0f;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = "
            << result << std::endl;
    }
    catch (const std::invalid_argument& ex)
    {
        std::cout << "[Error] Invalid argument in do_division: "
            << ex.what() << std::endl;
    }
    // Any other exception type here would violate the noexcept contract
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomApplicationException& ex)
    {
        std::cout << "[Error] CustomApplicationException in main: "
            << ex.what() << std::endl;
    }
    catch (const std::exception& ex)
    {
        std::cout << "[Error] std::exception in main: "
            << ex.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "[Error] Unknown exception type in main." << std::endl;
    }

    std::cout << "Program has completed exception tests and will now exit."
        << std::endl;
}