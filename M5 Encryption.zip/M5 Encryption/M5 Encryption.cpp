// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>
#include <string>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // Cache lengths for efficiency.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Validate inputs.
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // XOR each character with a repeating key.
    for (size_t i = 0; i < source_length; ++i)
    {
        char k = key[i % key_length];
        output[i] = source[i] ^ k;
    }

    assert(output.length() == source_length);
    return output;
}

std::string read_file(const std::string& filename)
{
    // Read entire file into a single string.
    std::ifstream in(filename, std::ios::binary);
    if (!in)
    {
        std::cerr << "Failed to open input file: " << filename << std::endl;
        return {};
    }

    std::ostringstream buffer;
    buffer << in.rdbuf();
    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // Student name is on the first line.
    size_t pos = string_data.find('\n');
    if (pos != std::string::npos)
    {
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename,
    const std::string& student_name,
    const std::string& key,
    const std::string& data)
{
    // Save metadata and data in a consistent format.
    std::ofstream out(filename, std::ios::binary);
    if (!out)
    {
        std::cerr << "Failed to open output file: " << filename << std::endl;
        return;
    }

    // Line 1: student name
    out << student_name << '\n';

    // Line 2: current date (yyyy-mm-dd)
    std::time_t now = std::time(nullptr);
    std::tm tm_info{};
    localtime_s(&tm_info, &now);
    out << std::put_time(&tm_info, "%Y-%m-%d") << '\n';

    // Line 3: key used
    out << key << '\n';

    // Line 4+: data (encrypted or decrypted)
    out << data;
}

int main()
{
    std::cout << "Encyption Decryption Test!" << std::endl;

    // Input file format:
    // Line 1: student name
    // Line 2: lorem ipsum generator URL
    // Lines 3+: three paragraphs of lorem ipsum text
    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";
    const std::string key = "password";

    // Load full file content.
    const std::string source_string = read_file(file_name);

    // Extract student name from first line.
    const std::string student_name = get_student_name(source_string);

    // Encrypt and save.
    const std::string encrypted_string = encrypt_decrypt(source_string, key);
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt and save.
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name
        << " - Encrypted To: " << encrypted_file_name
        << " - Decrypted To: " << decrypted_file_name << std::endl;

    // students submit input file, encrypted file, decrypted file, source code file, and key used
}